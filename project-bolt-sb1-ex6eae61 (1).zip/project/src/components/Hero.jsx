import React from 'react';
import { motion } from 'framer-motion';

const Hero = () => {
  return (
    <section className="pt-20 pb-12 bg-gradient-to-r from-blue-50 to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:w-1/2 text-center lg:text-left"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              Start Your Business Journey With Us
            </h1>
            <p className="mt-4 text-xl text-gray-600">
              Register your company hassle-free with our expert guidance and support.
            </p>
            <div className="mt-8 space-x-4">
              <button className="bg-primary text-white px-8 py-3 rounded-md hover:bg-secondary transition-colors">
                Get Started
              </button>
              <button className="border-2 border-primary text-primary px-8 py-3 rounded-md hover:bg-primary hover:text-white transition-colors">
                Learn More
              </button>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:w-1/2 mt-8 lg:mt-0"
          >
            <img
              src="https://raw.githubusercontent.com/stackblitz/stackblitz-icons/main/public/logo.svg"
              alt="Business Registration"
              className="w-full h-auto"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;