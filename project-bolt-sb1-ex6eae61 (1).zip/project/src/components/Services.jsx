import React from 'react';
import { motion } from 'framer-motion';
import { FaBuilding, FaTrademark, FaHandshake, FaGlobe } from 'react-icons/fa';

const services = [
  {
    icon: <FaBuilding className="w-12 h-12 text-primary" />,
    title: 'Company Registration',
    description: 'Register your private limited company, LLP, or proprietorship firm'
  },
  {
    icon: <FaTrademark className="w-12 h-12 text-primary" />,
    title: 'Trademark Registration',
    description: 'Protect your brand identity with trademark registration'
  },
  {
    icon: <FaHandshake className="w-12 h-12 text-primary" />,
    title: 'Business Licenses',
    description: 'Obtain all necessary business licenses and permits'
  },
  {
    icon: <FaGlobe className="w-12 h-12 text-primary" />,
    title: 'GST Registration',
    description: 'Complete GST registration and compliance services'
  }
];

const Services = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Our Services</h2>
          <p className="mt-4 text-xl text-gray-600">Comprehensive business registration services</p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-lg p-8 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="flex justify-center mb-6">{service.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 text-center mb-4">{service.title}</h3>
              <p className="text-gray-600 text-center">{service.description}</p>
              <button className="mt-6 w-full bg-primary text-white px-4 py-2 rounded-md hover:bg-secondary transition-colors">
                Learn More
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;