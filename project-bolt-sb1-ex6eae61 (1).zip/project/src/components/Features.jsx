import React from 'react';
import { motion } from 'framer-motion';
import { FaCheckCircle, FaClock, FaUserTie, FaFileContract } from 'react-icons/fa';

const features = [
  {
    icon: <FaCheckCircle className="w-8 h-8 text-primary" />,
    title: 'Easy Process',
    description: 'Simple and straightforward company registration process'
  },
  {
    icon: <FaClock className="w-8 h-8 text-primary" />,
    title: 'Quick Registration',
    description: 'Fast-track your company registration within days'
  },
  {
    icon: <FaUserTie className="w-8 h-8 text-primary" />,
    title: 'Expert Support',
    description: '24/7 support from our experienced professionals'
  },
  {
    icon: <FaFileContract className="w-8 h-8 text-primary" />,
    title: 'Complete Documentation',
    description: 'Comprehensive documentation handling and support'
  }
];

const Features = () => {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Why Choose Us</h2>
          <p className="mt-4 text-xl text-gray-600">We make company registration simple and efficient</p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex flex-col items-center text-center p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;