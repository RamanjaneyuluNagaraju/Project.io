/*
  # Food Wastage Exchange Schema

  1. New Tables
    - food_listings
      - id (uuid, primary key)
      - hotel_id (uuid, references auth.users)
      - food_name (text)
      - quantity (numeric)
      - preservation_time (numeric)
      - description (text)
      - is_available (boolean)
      - created_at (timestamp)
    
    - reservations
      - id (uuid, primary key)
      - listing_id (uuid, references food_listings)
      - user_id (uuid, references auth.users)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for CRUD operations
*/

-- Create food_listings table
CREATE TABLE food_listings (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    hotel_id uuid REFERENCES auth.users NOT NULL,
    food_name text NOT NULL,
    quantity numeric NOT NULL,
    preservation_time numeric NOT NULL,
    description text,
    is_available boolean DEFAULT true,
    created_at timestamptz DEFAULT now()
);

-- Create reservations table
CREATE TABLE reservations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    listing_id uuid REFERENCES food_listings NOT NULL,
    user_id uuid REFERENCES auth.users NOT NULL,
    created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE food_listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE reservations ENABLE ROW LEVEL SECURITY;

-- Policies for food_listings
CREATE POLICY "Hotels can create their own listings"
    ON food_listings
    FOR INSERT
    TO authenticated
    WITH CHECK (
        auth.uid() = hotel_id AND
        EXISTS (
            SELECT 1 FROM auth.users
            WHERE id = auth.uid()
            AND raw_user_metadata->>'userType' = 'hotel'
        )
    );

CREATE POLICY "Anyone can view available food listings"
    ON food_listings
    FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Hotels can update their own listings"
    ON food_listings
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = hotel_id)
    WITH CHECK (auth.uid() = hotel_id);

-- Policies for reservations
CREATE POLICY "Trusts can create reservations"
    ON reservations
    FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM auth.users
            WHERE id = auth.uid()
            AND raw_user_metadata->>'userType' = 'trust'
        )
    );

CREATE POLICY "Users can view their own reservations"
    ON reservations
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);